## Flutter UBER UI Kit <img src="https://camo.githubusercontent.com/a34cfbf37ba6848362bf2bee0f3915c2e38b1cc1/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f5052732d77656c636f6d652d627269676874677265656e2e7376673f7374796c653d666c61742d737175617265" />

A flutter Uber UI Kit inspired by [A design on behance](https://www.behance.net/gallery/84576871/JUBER-Car-Booking-mobile-UI-Kit)

20+ Screens and still making more. 😁😁

Star if you like what you see. ⭐⭐⭐⭐⭐

PRs are welcome ヽ(•‿•)ノ ヽ(•‿•)ノ

## Screenshots

<img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/1.png" width="200" />      <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/2.png" width="200" />            <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/3.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/4.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/5.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/6.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/7.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/8.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/9.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/10.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/11.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/12.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/13.png" width="200" />           <img src="https://github.com/OLayemii/uberr-ui/blob/US-fix-flow/screenshots/14.png" width="200" />

## 🦸‍♂️ Author


**Garuba OLayemii**

## 💃🏻💃🏻 Donate

| **Mode**       | **Link/Wallet**                                                              |
| -------------- | ---------------------------------------------------------------------------- |
| Bitcoin        | 1FHRt1kFnMdMbFUiTXKL6R1ZZ29thX8BrU                                           |
| Buy me a cofee | [https://www.buymeacoffee.com/xPGLYEr](https://www.buymeacoffee.com/xPGLYEr) |


## Special Thanks to:

<a href='https://www.github.com/vladbalan'>@vladbalan</a>

**Project is free to use/modify by anyone and everyone**

<a href="https://api.codemagic.io/artifacts/2372e1af-4905-47ff-8d22-62e624699e57/4144e029-a82a-4d42-8429-fd679b84b8e0/app.apk"><img src="https://playerzon.com/asset/download.png" width="200"></img></a>
