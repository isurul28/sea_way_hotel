class Destination {
  final String destinationText;

  Destination({this.destinationText});
}
